from django.forms import ModelForm
from .models import ListUrlsModel


class ListUrlsForm(ModelForm):

    class Meta:
        model = ListUrlsModel
        fields = ['file']
