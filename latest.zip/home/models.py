from django.db import models


class ListUrlsModel(models.Model):
    """File with urls"""
    name = models.TextField()
    file = models.FileField(upload_to='txt/')

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        self.name = self.file.name
        super().save(*args, **kwargs)
