from django.shortcuts import render
from .forms import ListUrlsForm


# Create your views here.


def index(request):
    if request.method == 'POST':
        form = ListUrlsForm(request.POST, request.FILES)
        list_urls = []
        if form.is_valid():
            # file is saved
            model_file = form.save()
            text_file = model_file.file.read()
            list_urls = text_file.decode('utf-8').split("\n")
            return render(request, 'home/index.html', {'form': form, 'urls': list_urls, 'name': model_file.name})
    else:
        form = ListUrlsForm()
        list_urls = ['no urls']
    return render(request, 'home/index.html', {'form': form, 'urls': list_urls})
