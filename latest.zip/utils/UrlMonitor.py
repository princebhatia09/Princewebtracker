import time
import platform
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import SessionNotCreatedException


class UrlMonitor:
    """Monitor one url"""

    def __init__(self, url):
        self.url = url
        self.path_web_driver = ""

        if platform.system() == "Linux":
            self.path_web_driver = os.path.abspath(
                "WebDriver/chromedriver_linux64/chromedriver")
        elif platform.system() == "Windows":
            self.path_web_driver = os.path.abspath(
                "WebDriver/chromedriver_win32/chromedriver")

        # Setting chrome without display
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-gpu')

        try:
            # Staring chrome
            self.driver_web_driver = webdriver.Chrome(
                executable_path=self.path_web_driver, options=chrome_options)

            # waiting to chrome load
            # self.driver_web_driver.implicitly_wait(10)
            self.driver_web_driver.get(
                'http://www.lodhamara.com/')

            time.sleep(10)

            # Making page static removing script and noscript tags
            self.driver_web_driver.execute_script(
                '''
                function deleteScripts() {
                    let scripts = document.getElementsByTagName('script')
                    for (let i = scripts.length - 1; i >= 0; i--) {
                        const element = scripts[i];
                        element.parentNode.removeChild(element);
                    }
                }

                function deleteNoScripts() {
                    let noscripts = document.getElementsByTagName('noscript')
                    for (let i = noscripts.length - 1; i >= 0; i--) {
                        const element = noscripts[i];
                        element.parentNode.removeChild(element);
                    }
                }

                deleteScripts();
                deleteNoScripts();
                return document.documentElement.outerHTML
                ''')

            # Getting code source of actual page
            self.html = self.driver_web_driver.page_source

            # TODO: Solving relative src and href in code
            # TODO: Save source code

            # self.html = self.driver_web_driver.execute_script(
            #     'return document.documentElement.outerHTML')
            self.driver_web_driver.close()
        except SessionNotCreatedException as e:
            print(e.msg)
        finally:
            pass


monitor = UrlMonitor("url")
print(monitor.html)
