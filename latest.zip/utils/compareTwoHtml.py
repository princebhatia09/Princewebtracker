import re
from lxml import html

# patterns
re.compile("( *< *script.*>)(<\/ *script>)")
re.compile("(<!--)+.+(-->)")


def clean_html(html_arg):
    """Delete comments, script and noscript from html"""
    document = html.document_fromstring(html_arg)
    document_cleaned = html.tostring(document)
    return str(document_cleaned.text)


def compare_two_html(html1, html2):
    """Compare two html without comments, script and noscript"""
    cleaned_html1 = clean_html(html1)

    with open('helpernew.html', 'w') as cleaned_new:
        cleaned_new.write(str(result))


with open('newPage.html', 'r') as new_page_file:
    compare_two_html(new_page, new_page)
