function deleteScripts() {
    let scripts = document.getElementsByTagName('script')
    for (let i = scripts.length - 1; i >= 0; i--) {
        const element = scripts[i];
        element.parentNode.removeChild(element);
    }
}

function deleteNoScripts() {
    let noscripts = document.getElementsByTagName('noscript')
    for (let i = noscripts.length - 1; i >= 0; i--) {
        const element = noscripts[i];
        element.parentNode.removeChild(element);
    }
}

deleteScripts()
deleteNoScripts()
return document.documentElement.outerHTML